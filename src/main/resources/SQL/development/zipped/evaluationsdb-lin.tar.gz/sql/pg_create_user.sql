DROP USER IF EXISTS evaluations;

CREATE USER evaluations
WITH PASSWORD 'p4ssw0rd';